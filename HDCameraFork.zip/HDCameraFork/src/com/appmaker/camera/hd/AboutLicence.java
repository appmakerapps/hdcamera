package com.appmaker.camera.hd;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebView;

import com.appmaker.camera.hd.R;

public class AboutLicence extends Activity 
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.web_applicence);
		
		WebView view = (WebView)findViewById(R.id.webview);
		view.getSettings().setJavaScriptEnabled(true);
		view.loadUrl("file:///android_asset/about.html");
		view.setBackgroundColor(Color.BLACK);
		
	}

}
