package com.appmaker.camera.hd;

import android.content.Context;
import android.preference.PreferenceManager;

public class IAPCheck
{

	Context context;
	
	public IAPCheck(Context context)
	{
		this.context = context;
	}
	
	public void savePurchased(boolean state)
	{
		PreferenceManager.getDefaultSharedPreferences(context).edit().putBoolean("FLAG_ADS", state).commit();
	}
	
	public boolean getPurchased()
	{
		return PreferenceManager.getDefaultSharedPreferences(context).getBoolean("FLAG_ADS", true);
	}
	
}
