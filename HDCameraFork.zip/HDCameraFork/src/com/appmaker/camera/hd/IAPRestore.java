package com.appmaker.camera.hd;

import android.content.Context;
import android.content.SharedPreferences;

public class IAPRestore
{
    private final static int LAUNCHES_UNTIL_PROMPT = 3;
    
    static boolean iapreloadnow;
    
    public static void iap_launched(Context mContext)
    {
        SharedPreferences prefs = mContext.getSharedPreferences("iapreset", 0);
        if (prefs.getBoolean("dontshowagain", false))
        {
        	return ; 
        }
        
        SharedPreferences.Editor editor = prefs.edit();
        
        // Increment launch counter
        long launch_count = prefs.getLong("launch_count", 0) + 1;
        editor.putLong("launch_count", launch_count);
        
        editor.commit();
    }   
    
    public static boolean isIAPReload(final Context mContext)
    {
    	SharedPreferences prefs = mContext.getSharedPreferences("iapreset", 0);
    	long launch_count = prefs.getLong("launch_count", 0) + 1;
    	if (launch_count >= LAUNCHES_UNTIL_PROMPT) 
        {
            return true;
        }
    	else
    	{
    		return false;
    	}
    }
    
    public static void resetLaunch(final Context mContext)
    {
    	SharedPreferences prefs = mContext.getSharedPreferences("iapreset", 0);
    	SharedPreferences.Editor editor = prefs.edit();
    	editor.putLong("launch_count", 0);
        editor.commit();
    }
}

