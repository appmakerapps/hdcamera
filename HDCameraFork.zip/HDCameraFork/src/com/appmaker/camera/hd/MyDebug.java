package com.appmaker.camera.hd;

public class MyDebug {
	public static final boolean LOG = false;
}
