package com.appmaker.camera.hd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class Splash_Screen extends Activity 
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.spalshscreen);
		
		new Handler().postDelayed(new Runnable()
		{			
			@Override
			public void run()
			{
				startActivity(new Intent(Splash_Screen.this, MainActivity.class));
			}
		}, 1500);
	}

}
