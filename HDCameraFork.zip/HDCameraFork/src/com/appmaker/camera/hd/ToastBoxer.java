package com.appmaker.camera.hd;

import android.widget.Toast;

public class ToastBoxer {
	public Toast toast = null;

	public ToastBoxer() {
	}
}
